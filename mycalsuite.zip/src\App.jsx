import React from "react";
import { Routes, Route } from "react-router-dom";

import UnitConverter from "./pages/UnitConverter";
import CalculatorPage from "./pages/CalculatorPage";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsOfUse from "./pages/TermsOfUse";
import PercentagePage from "./pages/PercentagePage";

import BmiPage from './pages/BmiPage';
function App() {
  return (
    <Routes>
      <Route path="/" element={<UnitConverter />} />
      <Route path="/calculator" element={<CalculatorPage/>} />
      <Route path="/bmi" element={<BmiPage/>} />
      <Route path="/privacypolicy" element={<PrivacyPolicy/>} />
      <Route path="/termsofuse" element={<TermsOfUse/>} />
      <Route path="/percentage" element={<PercentagePage/>} />

    </Routes>
  );
}

export default App;
