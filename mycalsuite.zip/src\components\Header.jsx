import React from "react";
import logo from "../assets/logo.png"; // adjust path if needed

export default function Header() {
  return (
    <header className="w-full bg-blue-900 p-2 flex items-center justify-center">
      {/* Logo Only */}
      <img
        src={logo}
        alt="MyCalSuite Logo"
        className="h-6 w-auto md:h-8 md:w-auto"
      />
    </header>
  );
}
