import React, { useState } from "react";

export default function BMI() {
  const [unit, setUnit] = useState("metric");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("male");
  const [heightFeet, setHeightFeet] = useState("");
  const [heightInch, setHeightInch] = useState("");
  const [heightCm, setHeightCm] = useState("");
  const [weight, setWeight] = useState("");
  const [result, setResult] = useState(null);

  const calculateBMI = () => {
    let heightInMeters = 0;

    if (unit === "us") {
      const totalInches =
        parseFloat(heightFeet || 0) * 12 + parseFloat(heightInch || 0);
      heightInMeters = totalInches * 0.0254;
    } else {
      heightInMeters = parseFloat(heightCm || 0) / 100;
    }

    const weightKg =
      unit === "us"
        ? parseFloat(weight || 0) * 0.453592
        : parseFloat(weight || 0);

    if (!age || !weightKg || !heightInMeters) {
      setResult("⚠ Please fill all required fields correctly.");
      return;
    }

    const bmi = weightKg / (heightInMeters * heightInMeters);

    let category = "";
    if (age < 2) {
      category = "BMI calculation not applicable under age 2.";
    } else if (age >= 2 && age < 20) {
      if (bmi < 14) category = "Underweight (<5%)";
      else if (bmi < 18) category = "Healthy weight (5% - 85%)";
      else if (bmi < 22) category = "At risk of overweight (85% - 95%)";
      else category = "Overweight (>95%)";
    } else {
      if (bmi < 16) category = "Severe Thinness";
      else if (bmi < 17) category = "Moderate Thinness";
      else if (bmi < 18.5) category = "Mild Thinness";
      else if (bmi < 25) category = "Normal";
      else if (bmi < 30) category = "Overweight";
      else if (bmi < 35) category = "Obese Class I";
      else if (bmi < 40) category = "Obese Class II";
      else category = "Obese Class III";
    }

    setResult(`Your BMI is ${bmi.toFixed(2)} → ${category}`);
  };

  const clearAll = () => {
    setAge("");
    setGender("male");
    setHeightFeet("");
    setHeightInch("");
    setHeightCm("");
    setWeight("");
    setResult(null);
  };

  return (
    <div className="max-w-4xl mx-auto px-4">
  {/* Outer Grid with Two Columns */}
  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
    {/* First Column: Menu + Form */}
    <div>
      {/* Menu */}
      <div className="flex gap-1 justify-start ">
        <button
          onClick={() => setUnit("us")}
          className={`px-4 py-2 text-sm sm:text-base text-white rounded ${
            unit === "us" ? "bg-blue-900" : "bg-gray-400"
          }`}
        >
          US Units
        </button>
        <button
          onClick={() => setUnit("metric")}
          className={`px-4 py-2 text-sm sm:text-base text-white rounded ${
            unit === "metric" ? "bg-blue-900" : "bg-gray-400"
          }`}
        >
          Metric Units
        </button>
      </div>

      {/* Input Form Box */}
      <div className="border-4 border-blue-100 p-4 space-y-4 shadow-md bg-gray-50 rounded-lg">
        {/* Age */}
        <div className="flex items-center gap-2">
          <label className="w-24 text-sm sm:text-base">Age:</label>
          <input
            type="number"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            className="border border-gray-300 p-2 flex-1 text-sm sm:text-base"
            placeholder="Enter age"
          />
        </div>

        {/* Gender */}
        <div className="flex items-center gap-2">
          <label className="w-24 text-sm sm:text-base">Gender:</label>
          <div className="flex gap-4">
            <label className="text-sm sm:text-base">
              <input
                type="radio"
                value="male"
                checked={gender === "male"}
                onChange={(e) => setGender(e.target.value)}
                className="mr-1"
              />
              Male
            </label>
            <label className="text-sm sm:text-base">
              <input
                type="radio"
                value="female"
                checked={gender === "female"}
                onChange={(e) => setGender(e.target.value)}
                className="mr-1"
              />
              Female
            </label>
          </div>
        </div>

        {/* Height */}
        <div className="flex items-center gap-2">
          <label className="w-24 text-sm sm:text-base">Height:</label>
          {unit === "us" ? (
            <div className="flex gap-2 flex-1">
              <input
                type="number"
                value={heightFeet}
                onChange={(e) => setHeightFeet(e.target.value)}
                className="border border-gray-400 p-2 w-1/2 text-sm sm:text-base"
                placeholder="Feet"
              />
              <input
                type="number"
                value={heightInch}
                onChange={(e) => setHeightInch(e.target.value)}
                className="border border-gray-400 p-2 w-1/2 text-sm sm:text-base"
                placeholder="Inches"
              />
            </div>
          ) : (
            <input
              type="number"
              value={heightCm}
              onChange={(e) => setHeightCm(e.target.value)}
              className="border border-gray-400 p-2 flex-1 text-sm sm:text-base"
              placeholder="cm"
            />
          )}
        </div>

        {/* Weight */}
        <div className="flex items-center gap-2">
          <label className="w-24 text-sm sm:text-base">Weight:</label>
          <input
            type="number"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            className="border border-gray-400 p-2 flex-1 text-sm sm:text-base"
            placeholder={unit === "us" ? "lbs" : "kg"}
          />
        </div>

        {/* Buttons */}
        <div className="flex justify-center gap-2 mt-2">
          <button
            onClick={calculateBMI}
            className="bg-blue-900 text-white px-4 py-2 rounded-lg text-sm sm:text-base"
          >
            Calculate
          </button>
          <button
            onClick={clearAll}
            className="bg-gray-400 text-white px-4 py-2 rounded-lg text-sm sm:text-base"
          >
            Clear
          </button>
        </div>
      </div>
    </div>

    {/* Second Column: Result */}
    <div>
      <div className="border-4 border-green-200 p-4 shadow-md bg-gray-50 rounded-lg h-17/20 flex items-center justify-center md:mt-[40px]">
        {result ? (
          <div className="text-center font-semibold text-lg text-blue-900">
            <p className="text-gray-500 text-center text-xl">Result</p>
            {result}
            <p className="text-gray-500 text-center text-xl mt-[30px]">Basic Information</p>
            <p className="text-start text-sm mt-[10px]">Healthy BMI range: 18.5 kg/m2 - 25 kg/m2</p>
             <p className="text-start text-sm mt-[10px]">Healthy weight for the Height: 59.9 kg - 81 kg</p>
              <p className="text-start text-sm mt-[10px]">  BMI Prime: 0.8 </p>
              <p className="text-start text-sm mt-[10px]">Ponderal Index: 11.1 kg/m3</p>
          </div>
        ) : (
          <p className="text-gray-500 text-center">Your BMI result will appear here</p>
        )}
      </div>
    </div>
  </div>
</div>

  );
}
